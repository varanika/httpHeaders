<?php

return [
    'modExtra' => [
        'description' => '',
        'type' => 'file',
        'content' => '',
        'namespace' => 'modextra',
        'lexicon' => 'modextra:dashboards',
        'size' => 'half',
    ],
];