<?php

return [
    'modExtra' => [
        'file' => 'modextra',
        'description' => '',
        'events' => [
            'OnManagerPageInit' => [],
        ],
    ],
];