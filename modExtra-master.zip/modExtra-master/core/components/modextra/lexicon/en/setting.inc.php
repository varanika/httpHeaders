<?php

$_lang['area_modextra_main'] = 'Main';

$_lang['setting_modextra_some_setting'] = 'Some setting';
$_lang['setting_modextra_some_setting_desc'] = 'This is description for some setting';