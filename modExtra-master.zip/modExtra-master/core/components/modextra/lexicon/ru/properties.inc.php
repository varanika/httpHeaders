<?php

$_lang['modextra_prop_limit'] = 'Ограничение вывода Предметов на странице.';
$_lang['modextra_prop_outputSeparator'] = 'Разделитель вывода строк.';
$_lang['modextra_prop_sortby'] = 'Поле сортировки.';
$_lang['modextra_prop_sortdir'] = 'Направление сортировки.';
$_lang['modextra_prop_tpl'] = 'Чанк оформления каждого ряда Предметов.';
$_lang['modextra_prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице.';
